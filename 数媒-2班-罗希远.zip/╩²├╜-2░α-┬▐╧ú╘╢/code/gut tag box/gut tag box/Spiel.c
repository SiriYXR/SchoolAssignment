#include"Funktion.h"

void init() {


	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO cci;
	GetConsoleCursorInfo(hOut, &cci);
	cci.bVisible = FALSE;
	SetConsoleCursorInfo(hOut, &cci);

	system("title ������1.0");
	system("mode con cols=120 lines=30");
}

void mainloop() {
	int level;
	int level_save;
	int scenes;
	char option;
	int isEnd;
	char map[50][50] = { 0 };
	int health;
	int charcter_level;
	int reValue;
	int maps_num;
	int *p;
	
	level = 0;
	scenes = 0;
	isEnd = 0;
	health = 100;
	charcter_level = 1;
	
	
	char main_menu[50][50] = {
		"\n\n\n\n\n\n\n",
		"\t\t\t\t\t\t\t    rpg��������",
		"\t\t\t\t\t\t   |===============|",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |  ������Ϸ(S)  |",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |  ������Ϸ(B)  |",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |   �˳�(ESC)   |",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |===============|",
	};
	char store_menu[100][100] = {
	"\n\n\n\n\n\n\n",
	"\t\t\t\t\t\t\t      ��ӭ�����̵꣬��������Ҫʲô",
	"\t\t\t\t\t\t   |===============================|",
	"\t\t\t\t\t\t   |         ������Ϸ(ESC)         |",
	"\t\t\t\t\t\t   |                               |",
	"\t\t\t\t\t\t   |  ��լ����ˮ(�ظ���������ֵ��  |",
	"\t\t\t\t\t\t   |     ����$500  press 1 to use  |",
	"\t\t\t\t\t\t   |                               |",
	"\t\t\t\t\t\t   |    ��Կ�ף�ֱ�ӽ�����һ�أ�   |",
	"\t\t\t\t\t\t   |      ����$2000  press 2 to use|",
	"\t\t\t\t\t\t   |                               |",
	"\t\t\t\t\t\t   |    �ֻ�(����ȼ�+1)           |",
	"\t\t\t\t\t\t   |     ����$1000  press 3 to use |",
	"\t\t\t\t\t\t   |===============================|",
	};
	char death_menu[100][100] = {
	"\n\n\n\n\n\n\n",
	"\t\t\t\t\t\t\t                                 ",
	"\t\t\t\t\t\t   |===============================|",
	"\t\t\t\t\t\t   |                               |",
	"\t\t\t\t\t\t   |                               |",
	"\t\t\t\t\t\t   |      ����Ϊ�����ľ�ϴ���ˣ�   |",
	"\t\t\t\t\t\t   |                               |",
	"\t\t\t\t\t\t   |        ����q���棩            |",
	"\t\t\t\t\t\t   |                               |",
	"\t\t\t\t\t\t   |                               |",
	"\t\t\t\t\t\t   |                               |",
	"\t\t\t\t\t\t   |                               |",
	"\t\t\t\t\t\t   |                               |",
	"\t\t\t\t\t\t   |===============================|",
	};

	while (1) {

		system("cls");
		switch (scenes) {
		case 0:
			for (int i = 0; i < 11; i++)
				puts(main_menu[i]);
			break;
		case 1:
			for (int i = 0; i < 12; i++)
				puts(store_menu[i]);
			break;
		case 2:
			for (int i = 0; i < 12; i++)
				puts(death_menu[i]);
			break;
		default:
			break;
		}
		if (scenes < 3) {
			option = getch();
			option = tolower(option);
		}
		switch (scenes) {
		case 0:
			if (option == 's')
				printf("ĳһ����˯�������������㴩Խ���������ӵ���Ϸ���������Ҫ���ú������ϵ���Ʒ�����ݽ��ӳ�����");
			Sleep(50);
			scenes = 1;
			if (option == 27) {
				isEnd = 1;
			}
			break;
		case 1:
			if (option == 'b')
				scenes = gameloop(level_save);
			break;
		case 3:
			level = 0;
			scenes = gameloop(level);
			break;
		case 4:
			scenes = gameloop(level);
			break;
		case 5:
			level++;
			scenes = 4;
		case 6:
			scenes = 0;
			level = 0;
			break;
		default:
			break;
			if (isEnd)
				break;
		}
		switch (scenes) {
		case 1:
			if (option == '1')
				health = charcter_level + 99;
			scenes = gameloop(level_save);
			if (option == '2')
				level_save++;
			scenes = gameloop(level_save);
			if (option == '3')
				charcter_level++;
			health = charcter_level + 99;
			scenes = gameloop(level_save);
			if (option == 27);
			scenes = gameloop(level_save);
		}
		switch (scenes) {
		case 2:
			if (option == 'q')
				reValue = 4;
			isEnd = 1;
		}
	}
		int gameloop(int level);
		{
			int x, y;
			int wide;
			char option;
			int scenes;
			int isEnd;
			int reValue;
			int top;
			int lastStep_num;

			char map[50][50] = { 0 };

			int aim_x[50] = { 0 }, aim_y[50] = { 0 }, xnum, ynum;

			int step_num;
			int box_x, box_y;
			int box_nx, box_ny;
			int last_x, last_y;

			int health;
			int money;
			int exp;
			int charcter_level;
			int death_count;


			wide = 0;
			step_num = 0;
			option = NULL;
			xnum = ynum = 0;
			scenes = 0;
			reValue = 0;
			isEnd = 0;
			top = 0;
			health = 100;
			money = 0;
			exp = 0;
			charcter_level = 1;

			LoadMap(level, map);

			wide = strlen(map[0]);

			for (int i = 0; i < 20; i++) {
				for (int t = 0; map[i][t] != '\0'; t++)
					if (map[i][t] == '@') {
						x = i;
						y = t;
						i = 99;
						break;
					}
			}

			for (int i = 2; i < 20; i++) {
				for (int t = 2; map[i][t] != '\0'; t++) {
					if (map[i][t] == 'X' || map[i][t] == 'Q') {
						aim_x[xnum] = i;
						aim_y[ynum] = t;
						xnum++;
						ynum++;
					}
					if (map[i][1] == '|') {
						i = 99;
						break;
					}
				}
			}

			while (1) {

				system("cls");
				switch (scenes) {
				case 0:
					printf("\n\n\n\n\n\t\t\t\t\t\t             ��%d��", level + 1);
					printf("\n\n");
					for (int i = 0; i <= 17; i++)
					{
						for (int t = 0; t < (120 - wide) / 2; t++)
							printf(" ");
						puts(map[i]);
					}
					printf("\t\t\t\ ��Ǯ:%d ����:%d ��ǰ����ȼ�:%d ����һ�ȼ�����:%d exp", money, step_num, charcter_level, exp);
					printf("\n\n\t\t �����̵�(Z) �浵(X) ���˵�(ESC)");
					break;
				case 1:

					printf("\n\n\n\n\n\t\t\t\t\t\t        ����(R)\n");
					if (level == maps_num - 1)
						printf("\n\n\t\t\t\t           ����(Q)  ���˵�(M)  \n");
					else
						printf("\n\n\t\t\t\t           ����(Q)  ��һ��(N)  ���˵�(M)  \n");
					printf("\n\n\n\t\t\t\t\t\t      ����˵��");
					printf("\n\n\t\t\t\t\t        W:��  S:��  A:��  D:��");
					printf("\n\n\t\t\t\t\t         @:��  O:����  X:�յ� ");
					break;
				case 2:

					if (level == maps_num - 1)
						printf("\n\n\n\n\n\n\n\t\t\t\t\t\t���Ѵ�ج�������ѹ�����");
					else
						printf("\n\n\n\n\n\n\n\t\t\t\t\t\t\t  �ڴ����´ε��ֻ�!");
					printf("\n\n\t\t\t\t\t\t    �����ܼƲ�����%d", step_num);
					if (level == maps_num - 1)
						printf("\n\n\t\t\t\t\t  ����(Q)  ���˵�(M)  \n");
					else
						printf("\n\n\t\t\t\t\t  ����(Q)  ��һ��(N)  ���˵�(M)  \n");
					break;
				default:
					break;
				}



				option = getch();
				option = tolower(option);


				switch (scenes) {
				case 0:
					if (option == 's') {

						if (map[x + 1][y] == ' ' || map[x + 1][y] == 'X') {
							map[x][y] = ' ';
							x++;
							map[x][y] = '@';
							step_num++;
							health--;
						}

						else if ((map[x + 1][y] == 'O' || map[x + 1][y] == 'Q') && map[x + 2][y] != 'O' && map[x + 2][y] != 'Q' && map[x + 2][y] != '#') {
							map[x][y] = ' ';


							last_x = x;
							last_y = y;

							x++;


							box_nx = x;
							box_ny = y;

							map[x][y] = '@';
							map[x + 1][y] = 'O';


							box_x = x + 1;
							box_y = y;

							lastStep_num = step_num;
							step_num++;
						}
					}
					else if (option == 'w') {
						if (map[x - 1][y] == ' ' || map[x - 1][y] == 'X') {
							map[x][y] = ' ';
							x--;
							map[x][y] = '@';
							step_num++;
							health--;
						}
						else if ((map[x - 1][y] == 'O' || map[x - 1][y] == 'Q') && map[x - 2][y] != 'O' && map[x - 2][y] != 'Q' && map[x - 2][y] != '#') {
							map[x][y] = ' ';


							last_x = x;
							last_y = y;

							x--;


							box_nx = x;
							box_ny = y;

							map[x][y] = '@';
							map[x - 1][y] = 'O';


							box_x = x - 1;
							box_y = y;

							lastStep_num = step_num;
							step_num++;
						}
					}
					else if (option == 'a') {
						if (map[x][y - 1] == ' ' || map[x][y - 1] == 'X') {
							map[x][y] = ' ';
							y--;
							map[x][y] = '@';
							step_num++;
							health--;
						}
						else if ((map[x][y - 1] == 'O' || map[x][y - 1] == 'Q') && map[x][y - 2] != 'O' && map[x][y - 2] != 'Q' && map[x][y - 2] != '#') {
							map[x][y] = ' ';


							last_x = x;
							last_y = y;

							y--;


							box_nx = x;
							box_ny = y;

							map[x][y] = '@';
							map[x][y - 1] = 'O';



							box_x = x;
							box_y = y - 1;

							lastStep_num = step_num;
							step_num++;
						}
						break;
					}
					else if (option == 'd') {
						if (map[x][y + 1] == ' ' || map[x][y + 1] == 'X') {
							map[x][y] = ' ';
							y++;
							map[x][y] = '@';
							step_num++;
						}
						else if ((map[x][y + 1] == 'O' || map[x][y + 1] == 'Q') && map[x][y + 2] != 'O' && map[x][y + 2] != 'Q'&&map[x][y + 2] != '#') {
							map[x][y] = ' ';


							last_x = x;
							last_y = y;

							y++;


							box_nx = x;
							box_ny = y;

							map[x][y] = '@';
							map[x][y + 1] = 'O';



							box_x = x;
							box_y = y + 1;

							lastStep_num = step_num;
							step_num++;
							health--;
						}
					}
					else if (option == 'z') {
						reValue = 1;
						isEnd = 1;
					}
					else if (option == 'x') {
						level_save = level;
					}
					break;
				case 1:
					if (option == 'm') {
						reValue = 0;
						isEnd = 1;
					}
					else if (option == 'r' || option == 27) {
						scenes = 0;
					}
					else if (option == 'q') {
						reValue = 4;
						isEnd = 1;
					}
					else if (option == 'n'&&level != maps_num - 1) {
						reValue = 5;
						isEnd = 1;
					}
					break;
				case 2:
					if (option == 'q') {
						reValue = 4;
						isEnd = 1;
					}
					else if (option == 'm') {
						reValue = 1;
						isEnd = 1;
					}
					else if (option == 'n'&&level != maps_num - 1) {
						reValue = 5;
						isEnd = 1;
					}
					break;
				default:
					break;
				}


				for (int i = 0; aim_x[i] != 0; i++) {
					if (map[aim_x[i]][aim_y[i]] == ' ')
						map[aim_x[i]][aim_y[i]] = 'X';
					if (map[aim_x[i]][aim_y[i]] == 'O')
						map[aim_x[i]][aim_y[i]] = 'Q';
				}

				int count = 0;
				for (int i = 0; aim_x[i] != 0; i++) {
					if (map[aim_x[i]][aim_y[i]] == 'Q')
						count++;
				}
				if (count == xnum) {
					money = money + (100 - step_num) * 50;
					exp = exp - (100 - step_num) * 10;
					if (exp <= 0)
					{
						charcter_level++;
						exp = (charcter_level) * 20;
						health = charcter_level + 99;
					}
					scenes = 2;
				}


				int death_count = 0;
				if (health <= 0)
					death_count++;
				for (int i = 0; i < 12; i++)
					puts(death_menu[i]);
				if (isEnd)
					break;
			}

			return reValue;
		}

		void LoadMap(int level, char(*map)[50]);
		{
			char buffer[256];
			FILE *fp;
			sprintf(buffer, "data\\Map\\%d.txt", level + 1);
			fp = fopen(buffer, "r");
			for (int i = 0;; i++) {
				fgets(map[i], 256, fp);
				map[i][strlen(map[i]) - 1] = '\0';
				if (map[i][1] == '|') {
					map[i][1] = '=';
					level_save = level + 1;
					break;
				}
			}
			fclose(fp);
		}

		void SlowDisplay(char *p);
		{
			while (1)
			{
				if (*p != 0)
					printf("%c", *p++);
				else
					break;
				Sleep(100);
			}
		}
	}

int gameloop(int level)
{
	return 0;
}

void SlowDisplay(char *p)
{
}

void LoadMap(int level, char(*map)[50])
{
}
