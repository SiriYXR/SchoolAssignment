# Tuixiangzi
推箱子
=
成都大学信工学院学长课堂C/C+方向18级大一上学期学长课堂期末作业

简介
=
本项目为成都大学信工学院学长课堂C/C++方向18级大一上学期课程学长课堂期末作业

使用说明
=
本项目程序采用VS2017开发，项目相关资源库文件均包含在项目文件夹中，同时项目属性以相对路径进行配置，建议下载相同版本的开发软件进行使用，以免发生版本不兼容的问题.

项目链接
=
https://github.com/kongbaiRen/zuoye

===============================================================================

IGNB
=
本项目是一个纯C语言的Win32控制台推箱子游戏。

代码文件：

文件名　　　　　　　　说明<br>
function.h　　函数前置声明，全局变量声明<br>
main.c　　　　定义程序入口main()函数<br>
game.c　　　定义游戏循环，文件读取等函数<br>

资源文件：<br>

文件/文件夹名　说明<br>
source/Map　　存储游戏的地图文件<br>

简要流程框图：


![](https://github.com/kongbaiRen/TXZ-/blob/master/图片1.png)


游戏运行图：


![](https://github.com/kongbaiRen/TXZ-/blob/master/QQ图片20181207220006.png)
![](https://github.com/kongbaiRen/TXZ-/blob/master/QQ图片20181208100622.png)
![](https://github.com/kongbaiRen/TXZ-/blob/master/QQ图片20181207220013.png)
![](https://github.com/kongbaiRen/TXZ-/blob/master/QQ图片20181208100622.png)
![](https://github.com/kongbaiRen/TXZ-/blob/master/QQ图片20181207220020.png)
