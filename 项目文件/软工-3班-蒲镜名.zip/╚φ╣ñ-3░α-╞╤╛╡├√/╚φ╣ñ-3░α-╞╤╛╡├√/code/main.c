#include"function.h"

int main()
{


	intgame();
	return 0;
}