﻿#include "function.h"

//地面：（0）}  墙：（1）█ }  箱子：(2)☆；}   目的地：（3）※ }
						//人：（4）￥ }  箱子—目：（5） ★ } 人—目：（7）Ψ

void intgame()
{

	char main_interface[50][50] = {
"\n\n\n\n\n\n\n",
"\t\t\t\t\t\t\t 推箱子",
"\t\t\t\t\t\t   |===============|",
"\t\t\t\t\t\t   |               |",
"\t\t\t\t\t\t   |               |",
"\t\t\t\t\t\t   |    开始(S)    |",
"\t\t\t\t\t\t   |               |",
"\t\t\t\t\t\t   |   退出(ESC)   |",
"\t\t\t\t\t\t   |               |",
"\t\t\t\t\t\t   |               |",
"\t\t\t\t\t\t   |===============|",
	};
	char menu2[50][50] = {
		"\n\n\n\n\n\n\n\n",
		"\t\t\t\t\t\t\t 推箱子\n",
		"\t\t\t\t\t\t   |===============|",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |   从头开始(A) |",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |    选关(X)    |",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |    返回(r)    |",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |===============|"
	};
	int scenes = 0;
	int level_option=1;
	int isEnd = 0;
	int level = 1;
	while (1)
	{
		system("cls");//清空屏幕
		switch (scenes)
		{
		case 0:
			for (int i = 0; i < 11; i++)
				puts(main_interface[i]);
			break;
		case 1:
			for (int i = 0; i < 11; i++)
				puts(menu2[i]);
			break;
		case 2:
			//打印关卡选择界面
			printf("\n\n\n\n\n\n\n\n\n\n\n");
			printf("\t\t\t\t\t\t");
			printf("请选择关卡(1-%d):%d\n\t\t\t\t\t\t'A'上一关'd'下一关‘空格’或‘回车’开始", maps_num, level_option);
			break;
		case 6:
			printf("good job");
			break;
		default:
			break;
		}
		char key = getch();
		switch (scenes)
		{
		case 0:
			switch (key)
			{
			case 'S':
			case 's':
				scenes = 1;
				break;
			case 27:
				isEnd = 1;
				break;
			default:
				break;
			}
			break;
		case 1:
			switch (key)
		{
		case 'r':
		case 'R':
			scenes = 0;
			break;
		case 'a':
		case 'A':
			scenes = 3;
			break;
		case 'x':
		case 'X':
			scenes = 2;
			break;
		}
		case 2://关卡选择界面事件判定
		//如果level_option大于1则减小1，如果level_option小于maps_num则增加1，加入该判断以防止越界
			if ((key == 'a') && level_option > 1)
				level_option--;
			else if ((key == 'd') && level_option < maps_num)
				level_option++;
			else if ((key == 13 || key == 32)) {//如果输入为空格（32）或回车（13）则进入选择的关卡
				level = level_option - 1;//将当前关卡更新为选择的关卡，其对应关系为 level = level_option - 1
				scenes = 4;
			}
			else if (key == 27)
				scenes = 1;
			break;
		case 3:
			scenes = gameloop(level);
			break;
		case 4:
				level++;
				scenes = 3;
			break;
		case 6:
			isEnd = 1;
			getch();
			break;
		default:
			break;
		}
		if (isEnd)//如果结束判断变量为1（true）则跳出循环，即退出游戏
			break;
	}
}
int gameloop(level)
{
	int k = 0;//D
	int *j[100];
	char last_map[100][50][50];//C
	static i=0;
	int num = 0;
	int aim = 0;
	int reVel = 0;
	int isEnd = 0;
	int step_num = 0;
	int scenes = 0;
	int x = 0, y = 0;
	int last_y[1000] = { 0 };
	int last_x[1000] = { 0 };
	Map *map;
	map = LoadMap(level);
	//找箱子数num
	for (y = 0; y < 20; y++)
	{
		for (x = 0; x < 20; x++)
		{
			if (map->map[y][x] == '3' || map->map[y][x] == '5')
				num++;
		}
	}
	while (1)
	{
		//记录每一步的地图B
		for (int x = 0; x < map->h; x++)
		{
			for (int y = 0; y < map->len; y++)
			{
				last_map[k][x][y] = map->map[x][y];
			}
		}
		system("cls");
		switch (scenes) {
		case 0:
			//游戏界面//把数字地图以图形打印出来并居中
			printf("\n\n\n\n\n\n\n\n\n");
			for (int i = 0; i < map->h; i++)
			{
				printf("\t\t\t\t\t\t");
				for (int j = 0; j < 30; j++)
				{
					switch (map->map[i][j])
					{
						//地面：（0）}  墙：（1）█ }  箱子：(2)☆；}   目的地：（3）※ }
						//人：（4）￥ }  箱子—目：（5） ★ } 人—目：（7）Ψ
					case '0':
						printf("  ");
						break;
					case '1':
						printf("█");
						break;
					case '2':
						printf("☆");
						break;
					case '3':
						printf("※");
						break;
					case '4':
						printf("￥");
						break;
					case '5':
						printf("★");
						break;
					case '7':
						printf("Ψ");
						break;
					}
				}
				printf("\n");
			}//游戏界面显示在下方的信息
			printf("\t\t\t\t\t    人(￥) 箱子(☆) 目的地(※)");
			printf("\n\n\t\t\t\t\t\t  按(u)退步  步数:%d", step_num);
			printf("\n\n\n\t\t\t\t\t\t    返回(ESC)");
			break;
		case 1:
			//暂停界面
			printf("\n\n\n\n\n\t\t\t\t\t\t        继续(R)\n");
			if (level == maps_num - 1)//如果当前关卡为最后一关，则不显示"下一关(N)"
				printf("\n\n\t\t\t\t         选关(X)  重玩(Q)   主菜单(M)  \n");
			else
				printf("\n\n\t\t\t\t         选关(X)   重玩(Q)  下一关(N)  主菜单(M)  \n");
			break;
		case 2:
			//过关界面
			if (level == maps_num)//如果当前关卡为最后一关
			{printf("\n\n\n\n\n\n\n\t\t\t\t\t\t这已经是最后一关了！");
			printf("\n\n\t\t\t\t\t  选关(X)  重玩(Q)    主菜单(M)  任意键（esc）退出\n");
			}
			else
			{
				printf("\n\n\n\n\n\n\n\t\t\t\t\t\t\t  过关!");
				printf("\n\n\t\t\t\t\t\t    本关总计步数：%d", step_num);
				if (level == maps_num - 1)
					printf("\n\n\t\t\t\t\t  选关(X)  重玩(Q)  主菜单(M)  \n");
				else
					printf("\n\n\t\t\t\t\t  选关(X)  重玩(Q)  下一关(N)  主菜单(M)  \n");
			}
			break;
		default:
			break;
		}
		
		//找完成的个数aim
		int aim = 0;
		for (y = 0; y < 20; y++)
		{
			for (x = 0; x < 20; x++)
			{
				if (map->map[y][x] == '5')
					aim++;
			}
		}
		//找到人物的坐标，才能移动
		for (y = 0; y < 20; y++)
		{
			for (x = 0; x < 20; x++)
			{
				if (map->map[y][x] == '4' || map->map[y][x] == '7')
					break;
			}
			if (map->map[y][x] == '4' || map->map[y][x] == '7')
				break;
		}
		char opinion;
		opinion = getch();
		switch (scenes)
		{
		case 0:
			switch (opinion)
			{
				//直接过关
			case 'k':
			case 'K':
				scenes = 2;
				break;
				//上：72  下：80  左：75  右：77
				//地面：（0）}  墙：（1）█ }  箱子：(2)☆；}   目的地：（3）※ }
				//     人：（4） ￥}  箱子—目：（5） ★ } 人—目：（7）¥
			case 27:
				scenes = 1;
				break;
			case 'q':
				level = 0;
				reVel = 3;
				isEnd = 1;
			case 'u'://C
			case 'U':
				if (k < 100&&k>0)
				{
					for (int x = 0; x < map->h; x++)
					{
						for (int y = 0; y < map->len; y++)
						{
							map->map[x][y] = last_map[k - 1][x][y];
						}
					}
					k=k-2;
				}
				break;
			case 'w':
			case 'W':
				if (map->map[y - 1][x] == '0' || map->map[y - 1][x] == '3')
				{
					map->map[y][x] -= 4;
					map->map[y - 1][x] += 4;
					step_num++;
				}
				//判断人上面是不是箱子
				else if (map->map[y - 1][x] == '2' || map->map[y - 1][x] == '5')
				{
					//判断箱子上面是不是空地或目的地
					if (map->map[y - 2][x] == '0' || map->map[y - 2][x] == '3')
					{
						map->map[y - 2][x] += 2;
						map->map[y - 1][x] += 2;
						map->map[y][x] -= 4;
						step_num++;
					}
				}
			
				break;
			case 's':
			case 'S':
				if (map->map[y + 1][x] == '0' || map->map[y + 1][x] == '3')
				{
					map->map[y][x] = map->map[y][x] - 4;
					map->map[y + 1][x] += 4;
					step_num++;
				}
				//判断人下面是不是箱子
				else if (map->map[y + 1][x] == '2' || map->map[y + 1][x] == '5')
				{
					//判断箱子下面是不是空地或目的地
					if (map->map[y + 2][x] == '0' || map->map[y + 2][x] == '3')
					{
						map->map[y + 2][x] += 2;
						map->map[y + 1][x] += 2;
						map->map[y][x] -= 4;
						step_num++;
					}
				}
				break;
			case 'a':
			case 'A':
				if (map->map[y][x - 1] == '0' || map->map[y][x - 1] == '3')
				{
					map->map[y][x] = map->map[y][x] - 4;
					map->map[y][x - 1] += 4;
					step_num++;
				}
				//判断人左面是不是箱子
				else if (map->map[y][x - 1] == '2' || map->map[y][x - 1] == '5')
				{
					//判断箱子左面是不是空地或目的地
					if (map->map[y][x - 2] == '0' || map->map[y][x - 2] == '3')
					{
						map->map[y][x - 2] += 2;
						map->map[y][x - 1] += 2;
						map->map[y][x] -= 4;
						step_num++;
					}
				}
				
				break;
			case 'd':
			case 'D':
				if (map->map[y][x + 1] == '0' || map->map[y][x + 1] == '3')
				{
					map->map[y][x] = map->map[y][x] - 4;
					map->map[y][x + 1] += 4;
					step_num++;
				}
				//判断人左面是不是箱子
				else if (map->map[y][x + 1] == '2' || map->map[y][x + 1] == '5')
				{
					//判断箱子左面是不是空地或目的地
					if (map->map[y][x + 2] == '0' || map->map[y][x + 2] == '3')
					{
						map->map[y][x + 2] += 2;
						map->map[y][x + 1] += 2;
						map->map[y][x] -= 4;
						step_num++;
					}
				}
				
				break;
			}
			break;
		case 1:if (opinion == 'r' || opinion == 27) {//继续游戏
			scenes = 0;
		}
			   else if (opinion == 'x') {//进入到关卡选择界面，但中途推出关卡选择的话不会继续当前游戏，会回到主菜单
			reVel = 2;
			isEnd = 1;
		}   else if (opinion == 'q') {
			level = 0;
			reVel = 3;
			isEnd = 1;
		}
			   //如果当前不是最后一关，则进入下一关
		  else if (opinion == 'n' && level != maps_num - 1) {
			reVel =4;
			isEnd = 1;
		}
			   //返回主菜单
		  else if (opinion == 'm') {
			reVel = 1;
			isEnd = 1;
		}
			   //直接过关
			   else if (opinion == 'K' || opinion == 'k') {;
			scenes = 2;
		}
			   break;
		case 2:
			if (opinion == 'x') {
				reVel = 2;
				isEnd = 1;
			}
			else if (opinion == 'q') {
				reVel = 3;
				isEnd = 1;
			}
			else if (opinion == 'n'&&level != maps_num ) {
				reVel = 4;
				isEnd = 1;
			}
			else if (opinion == 'm') {
				reVel = 1;
				isEnd = 1;
			}
			else if (opinion == 27) {
				reVel = 6;
				isEnd = 1;
			}
			break;
		default:
			break;
		}
		if (num == aim)
		{
			scenes = 2;
		}
		k++;//地图参数加一//E
		if (isEnd)
			break;
	}
	return reVel;
}

Map* LoadMap(int level)
{
	Map* temp = (Map*)malloc(sizeof(Map));//为指针temp分配内存空间
	char buffer[256];
	FILE *fp;
	sprintf(buffer, "data/map/%d.txt", level);
	fp = fopen(buffer, "r");
	temp->level = level;
	for (int i = 0;; i++)
	{
		fgets(temp->map[i], 256, fp);
		temp->map[i][strlen(temp->map[i]) - 1] = '\0';//在字符串末尾手动加上结束符'\0'
		if (temp->map[i][1] == '9')
		{
			temp->map[i][1] = '1';
			temp->h = i + 1;
			break;
		}
		for (int j = 0; temp->map[1][j] != '\0'; j++)
		{
			temp->len = j+1;
		}
	}
	fclose(fp);
	return temp;
}


