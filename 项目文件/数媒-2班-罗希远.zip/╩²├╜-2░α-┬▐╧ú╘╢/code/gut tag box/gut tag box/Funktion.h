#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <string.h>
#define maps_nums 35


void init();


void mainloop();


int gameloop(int level);


void SlowDisplay(char *);


void LoadMap(int level, char(*map)[50]);
