#include"function.h"

int main()
{
	init();

	mainloop();

	return 0;
}