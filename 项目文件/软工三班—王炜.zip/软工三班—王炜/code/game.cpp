﻿#include"function.h"
int scenes = 0;//使其为全局变量，方便在其他函数的赋值

//游戏主体：绘制地图，移动，悔棋，判断通关条件
void GAME(int level)
{

	PIMAGE pimg_wall = newimage();
	PIMAGE pimg_boxred = newimage();
	PIMAGE pimg_box = newimage();
	PIMAGE pimg_aim = newimage();
	PIMAGE pimg_man = newimage();
	PIMAGE pimg_man2 = newimage();
	PIMAGE pimg_land = newimage();
	//PIMAGE pimg_black = newimage();
	getimage(pimg_wall, "data\\image\\wall.jpg", 0, 0);
	getimage(pimg_land, "data\\image\\land.png", 0, 0);
	getimage(pimg_box, "data\\image\\box.png", 0, 0);
	getimage(pimg_boxred, "data\\image\\boxred.png", 0, 0);
	getimage(pimg_aim, "data\\image\\aim.png", 0, 0);
	getimage(pimg_man, "data\\image\\man.jpg", 0, 0);
	getimage(pimg_man2, "data\\image\\man2.jpg", 0, 0);
	//getimage(pimg_wall, "data\\image\\black.jpg", 0, 0);
	int high=0, wide=0;
	int aim_mount = 0;//终点个数
	int step_num = 0;//步数
	int x=0;
	int y=0;
	//从这里到下面都是与悔棋有关的变量
	int hum_x=0, hum_y=0;//人物的位置
	int box_x=0, box_y=0;//人物推动箱子时箱子的位置
	int box_nx=0, box_ny=0;//人物推动箱子时箱子前面的位置
	int p[900] = { 0 }, m[900] = {0};//存放x和y的坐标,因为一个坐标我要给它三个空间存放，所以尽量大点
	//如果我推箱子的步数（不包括没有退箱子只走路的步数)超过了900/3=300的话就会出问题
	int I = 0, J = 0;//便于数组p和数组m的存取而定义的
	//从这里到上面都与悔棋有关的变量
	Map* map;
	map = LoadMap(level);//??
	//计算终点个数
	for (int i = 0; i <= map->h; i++)
	{
		for (int j = 0; j < strlen(map->map[0]); j++)
		{
			if (map->map[i][j] == '3')
				aim_mount += 1;
		}
	}
	//计算地图宽度
	wide = strlen(map->map[0]);
	//将地图高度值赋给high
	high = map->h;
	//计算地图居中偏移量
	high = (13 - high) / 2;
	wide = (16 - strlen(map->map[0])) / 2;

	for(;is_run();delay_fps(60))
	{
		//每运行一帧，计数器增加1，每计数到60清零
		int count=0;
		if (count > 60)
			count = 0;
		count += 2;
		//清屏
		cleardevice();
		//把数字地图以图形打印出来并居中
		for (int i = 0; i <= map->h; i++)
		{
			for (int j = 0; j < strlen(map->map[0]); j++)
			{
				switch (map->map[i][j])
				{
					//地面：（0）}  墙：（1）█ }  箱子：(2)☆；}   目的地：（3）※ }
					//人：（4）￥ }  箱子—目：（5） ★ } 人—目：（7）Ψ
				case '0':
					putimage(50 + j * 40 + wide * 40, 20 + i * 40 + high * 40, pimg_land);
					break;
				case '1':
					putimage(50 + j * 40 + wide * 40, 20 + i * 40 + high * 40, pimg_wall);
					break;
				case '2':
					putimage(50 + j * 40 + wide * 40, 20 + i * 40 + high * 40, pimg_box);
					break;
				case '3':
					putimage(50 + j * 40 + wide * 40, 20 + i * 40 + high * 40, pimg_aim);
					break;
				case '4':
					putimage(50 + j * 40 + wide * 40, 20 + i * 40 + high * 40, pimg_man);
					break;
				case '5':
					putimage(50 + j * 40 + wide * 40, 20 + i * 40 + high * 40, pimg_boxred);
					break;
				case '7':
					putimage(50 + j * 40 + wide * 40, 20 + i * 40 + high * 40, pimg_man2);
					break;
				default:
					break;
				}
			}
		}
		//游戏界面显示在下方的信息

		//找到人物的坐标，才能移动
		for (y = 0; y <= map->h; y++)
		{
			for (x = 0; x < strlen(map->map[0]); x++)
			{
				if (map->map[y][x] == '4' || map->map[y][x] == '7')
					break;
			}
			if (map->map[y][x] == '4' || map->map[y][x] == '7')
				break;
		}

		char opinion;
		opinion = getch();
		switch (opinion)
		{
			//上：72  下：80  左：75  右：77
			//地面：（0）}  墙：（1）█ }  箱子：(2)☆；}   目的地：（3）※ }
			//     人：（4） ￥}  箱子—目：（5） ★ } 人—目：（7）¥
		case 'w':
		case 'W':
		case 72:
			if (map->map[y - 1][x] == '0' || map->map[y - 1][x] == '3')
			{
				map->map[y][x] -= 4;
				map->map[y - 1][x] += 4;
				step_num++;
			}
			//判断人上面是不是箱子
			else if (map->map[y - 1][x] == '2' || map->map[y - 1][x] == '5')
			{
				//判断箱子上面是不是空地或目的地
				if (map->map[y - 2][x] == '0' || map->map[y - 2][x] == '3')
				{
					//记录坐标并依次存放到两个数组中
					hum_x = x; hum_y = y;
					box_x = x; box_y = y - 1;
					box_nx = x; box_ny = y - 2;
					p[I++] = hum_x; p[I++] = box_x; p[I++] = box_nx;
					m[J++] = hum_y; m[J++] = box_y; m[J++] = box_ny;
					//从这里到上面是与悔棋有关的
					map->map[y - 2][x] += 2;
					map->map[y - 1][x] += 2;
					map->map[y][x] -= 4;
					step_num++;
				}

			}

			break;

		case 's':
		case 'S':
		case 80:

			if (map->map[y + 1][x] == '0' || map->map[y + 1][x] == '3')
			{
				map->map[y][x] = map->map[y][x] - 4;
				map->map[y + 1][x] += 4;
				step_num++;
			}
			//判断人下面是不是箱子
			else if (map->map[y + 1][x] == '2' || map->map[y + 1][x] == '5')
			{
				//判断箱子下面是不是空地或目的地
				if (map->map[y + 2][x] == '0' || map->map[y + 2][x] == '3')
				{
					//记录坐标并依次存放到两个数组中
					hum_x = x; hum_y = y;
					box_x = x; box_y = y + 1;
					box_nx = x; box_ny = y + 2;
					p[I++] = hum_x; p[I++] = box_x; p[I++] = box_nx;
					m[J++] = hum_y; m[J++] = box_y; m[J++] = box_ny;
					//从这里到上面是与悔棋有关的
					map->map[y + 2][x] += 2;
					map->map[y + 1][x] += 2;
					map->map[y][x] -= 4;
					step_num++;
				}
			}
			break;
		case 'a':
		case 'A':
		case 75:

			if (map->map[y][x - 1] == '0' || map->map[y][x - 1] == '3')
			{
				map->map[y][x] = map->map[y][x] - 4;
				map->map[y][x - 1] += 4;
				step_num++;
			}
			//判断人左面是不是箱子
			else if (map->map[y][x - 1] == '2' || map->map[y][x - 1] == '5')
			{
				//判断箱子左面是不是空地或目的地
				if (map->map[y][x - 2] == '0' || map->map[y][x - 2] == '3')
				{
					//记录坐标并依次存放到两个数组中
					hum_x = x; hum_y = y;
					box_x = x - 1; box_y = y;
					box_nx = x - 2; box_ny = y;
					p[I++] = hum_x; p[I++] = box_x; p[I++] = box_nx;
					m[J++] = hum_y; m[J++] = box_y; m[J++] = box_ny;
					//从这里到上面是与悔棋有关的
					map->map[y][x - 2] += 2;
					map->map[y][x - 1] += 2;
					map->map[y][x] -= 4;
					step_num++;
				}
			}
			break;
		case 'd':
		case 'D':
		case 77:

			if (map->map[y][x + 1] == '0' || map->map[y][x + 1] == '3')
			{
				map->map[y][x] = map->map[y][x] - 4;
				map->map[y][x + 1] += 4;
				step_num++;
			}
			//判断人左面是不是箱子
			else if (map->map[y][x + 1] == '2' || map->map[y][x + 1] == '5')
			{
				//判断箱子左面是不是空地或目的地
				if (map->map[y][x + 2] == '0' || map->map[y][x + 2] == '3')
				{
					//记录坐标并依次存放到两个数组中
					hum_x = x; hum_y = y;
					box_x = x + 1; box_y = y;
					box_nx = x + 2; box_ny = y;
					p[I++] = hum_x; p[I++] = box_x; p[I++] = box_nx;
					m[J++] = hum_y; m[J++] = box_y; m[J++] = box_ny;
					//从这里到上面是与悔棋有关的
					map->map[y][x + 2] += 2;
					map->map[y][x + 1] += 2;
					map->map[y][x] -= 4;
					step_num++;
				}
			}
			break;
		case 'u':
		case 'U':
			//如果下面的成立，则不能退格，因为没有存储东西，说明没有推动箱子
			if (I == 0 || J == 0)
			{
				break;
			}
			map->map[y][x] -= 4;//将人物现在的变为上一步时存在的东西
			map->map[m[--J]][p[--I]] -= 2; //将箱子更新为人物推动箱子时箱子前面的东西
			int WW, WL;//因为如过不定义的话，下面switch加判断I和J总共会减两次，会造成错误
			WW = --J; WL = --I;
			switch (map->map[m[WW]][p[WL]])//怎么解释呢，打字说不清，要画图才行，所以算老嘛
			{
			case '7':map->map[m[WW]][p[WL]] -= 2;
				break;
			case '4':map->map[m[WW]][p[WL]] -= 2;
				break;
			case '0':map->map[m[WW]][p[WL]] += 2;
				break;
			case '3':map->map[m[WW]][p[WL]] += 2;
				break;
			}
			map->map[m[--J]][p[--I]] += 4;
			step_num--;//步数减一
			break;
		}
		//如果按下ESC返回界面1
		if (opinion == 27)
		{
			scenes = 1;
			break;
		}
		//令终点有箱子的数目为0
		int aim_achieve_mount = 0;
		//判断终点有箱子的数目
		for (int i = 0; i < 20; i++)
		{
			for (int j = 0; j < 20; j++)
				if (map->map[i][j] == '5')
				{
					aim_achieve_mount += 1;
				}
		}
		//如果终点有箱子的数目与终点的数目相同，则通关；即返回界面3
		if (aim_mount == aim_achieve_mount)
		{
			scenes = 3;
			break;
		}
	}

}

//游戏中的诸多界面界面

int Start(int level)
{

	while (is_run())
	{
		cleardevice();
		switch (scenes)//打印各页面
		{
		case 0:
			interface0();
			break;
		case 1:
			interface1();
			break;
		case 2:
			interface2(level);
			break;
		case 3:
			interface3();
			break;
		case 4:
			interface4();
			break;
		}


		char key;
		if (scenes < 5)//使页面可以执行
		{
			key = getch();
		}
		switch (scenes)//页面执行并运行其相应按键效果
		{
		case 0://主页面相关指令
			if (key == ' ')
			{
				scenes = 1;
			}
			else if (key == 27)
			{
				return 0;
			}
			break;
		case 1://第二界面相关指令
			if (key == 'I' || key == 'i')
			{
				GAME(level);

			}
			else if (key == 'P' || key == 'p')
			{
				scenes = 2;
			}
			else if (key == 27)
			{
				scenes = 0;
			}
			break;
		case 2://选关界面相关指令

				if (key == 'w' || key == 'W')
				{
					level++;
					break;
				}
				if (key == 's' || key == 'S')
				{
					if (level > 1)
					{
						level--;
						break;
					}
					else
						break;
				}
				if (key == 13)
				{
					GAME(level);
					break;
				}
			else if (key == '27' || key == '27')
			{
				scenes = 1;
			}
			break;
		case 3://过关界面相关指令
			if (key == ' ')
			{
				level += 1;//关卡加1
				//如果通关所有10个地图，则返回界面4
				if (level == 10)
				{
					scenes = 4;
					break;
				}
				GAME(level);

			}
			else if (key == 27)
			{
				scenes = 1;
			}
			break;
		case 4://通关全部地图后相关指令
			if (key == 27)
			{
				scenes = 0;
			}
		}
	}
	return 0;
}




//读取地图文件函数
Map* LoadMap(int level)
{
	Map* temp = (Map*)malloc(sizeof(Map));//为指针temp分配内存空间
	char buffer[256];
	FILE *fp;//定义文件指针
	sprintf(buffer, "data/map/%d.txt", level);

	fp = fopen(buffer, "r");//使地图以只读的方式打开

	temp->level = level;
	for (int i = 0;; i++)
	{
		fgets(temp->map[i], 256, fp);
		temp->map[i][strlen(temp->map[i]) - 1] = '\0';//在字符串末尾手动加上结束符'\0'
		//如果一行第二个数字出现9，则将其变为1并视为最后一行再退出
		if (temp->map[i][1] == '9')
		{
			temp->map[i][1] = '1';
			temp->h = i;
			break;
		}

	}
	fclose(fp);//关闭指针文件
	return temp;
}
