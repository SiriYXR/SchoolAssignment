#include"function.h"

//����ʼ�ĵط�
int main(int level)
{
	ege::initgraph(1000, 600);
	Start(level);
	ege::closegraph();
}