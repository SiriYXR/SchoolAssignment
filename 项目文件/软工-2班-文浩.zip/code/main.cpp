#include<stdio.h>
#include <stdlib.h>
#include <windows.h>
#include<string.h>
#include<conio.h>

#define maps_num 35//�ܹ��Ĺؿ�����
FILE *fp;
typedef struct Map {

	char map[50][50];
	int level;
	int h;
	int x;
	int y;
	int aim_count;
	int aimx[50];
	int aimy[50];

}Map;

//����ǰ������


void init();/*��飺��ʼ������,����������ֵ��*/

/*
��飺
������ѭ��
������
����ֵ��
*/
void mainloop();

/*
��飺
��Ϸѭ��
������
level:��ǰ��Ϸ���еĹؿ�
����ֵ��
reValue:��ѭ���ĳ���
*/
int gameloop(int level);

/*
��飺
��ȡ��Ϸ��ͼ
������
level:Ҫ��ȡ�Ĺؿ�
����ֵ��
*/
Map* LoadMap(int level);
int main()
{
	init();
	mainloop();

	system("pause");
	return 0;
}


void init() {

	//�öδ��빦�������ع�꣬������win32��̽ӿڣ�����Ҫ����
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);//��ȡ���ھ��
	CONSOLE_CURSOR_INFO cci;//ʵ�л�һ������̨�����Ϣ��
	GetConsoleCursorInfo(hOut, &cci);//��ȡ�����Ϣ
	cci.bVisible = FALSE;//���ع��
	SetConsoleCursorInfo(hOut, &cci);//���ù����Ϣ

	system("title ������1.0");//�趨��������
	system("mode con cols=120 lines=30");//�趨���ڴ�С
}

void mainloop() {

	//init

	char key = 0;

	int isEnd = 0;

	int scenes = 0;

	//������
	char main_interface[50][50] = {
		"\n\n\n\n\n\n\n",
		"\t\t\t\t\t\t\t ������",
		"\t\t\t\t\t\t   |===============|",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |    ��ʼ(S)    |",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |   �˳�(ESC)   |",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |===============|",
	};

	//���˵�2
	char menu2[50][50] = {
		"\n\n\n\n\n\n\n\n",
		"\t\t\t\t\t\t\t ������\n",
		"\t\t\t\t\t\t   |===============|",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |   ��ͷ��ʼ(A) |",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |    ѡ��(X)    |",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |    ����(ESC)  |",
		"\t\t\t\t\t\t   |               |",
		"\t\t\t\t\t\t   |===============|"
	};


	while (1)
	{

		//render
		system("cls");//�����Ļ
		switch (scenes)
		{
		case 0:
			for (int i = 0; i < 11; i++)
				puts(main_interface[i]);
			break;
		case 1:
			for (int i = 0; i < 11; i++)
				puts(menu2[i]);
			break;
		default:
			break;
		}


		//event
		key = _getch();

		switch (scenes)
		{
		case 0:
			switch (key)
			{
			case 'S':
			case 's':
				scenes = 1;
				break;
			case 27:

				isEnd = 1;
				break;
			default:
				break;
			}
			break;
		case 1:
			switch (key)
			{
			case 'A':
			case 'a':
				gameloop(1);
				break;
			case 27:
				scenes = 0;
				break;
			default:
				break;
			}
			break;
		default:
			break;
		}


		//update
		switch (scenes)
		{
		case 0:

			break;
		case 1:

			break;
		default:
			break;
		}
		if (isEnd)
			break;
	}


	//clear

}




int gameloop(int level) {

	int x = 5;
	int y = 5;

	int aim_count = 4;
	int aimx[20] = { 4,7,2,5 };
	int aimy[20] = { 2,4,5,7 };

	//init

	char key = 0;

	int isEnd = 0;

	int scenes = 0;

	Map *map;
	map = LoadMap(level);

	while (1)
	{

		//render
		system("cls");//�����Ļ
		switch (scenes)
		{
		case 0:
			for (int i = 0; i < map->h; i++)
				puts(map->map[i]);
			break;
		case 1:
			printf("good game!\n��N��������һ��");
			break;
		default:
			break;
		}


		//event
		key = _getch();

		switch (scenes)
		{
		case 0:
			switch (key)
			{
			case 'W':
			case 'w':
				switch (map->map[y - 1][x])
				{
				case ' ':
				case 'X':
					map->map[y - 1][x] = '@';
					map->map[y][x] = ' ';
					y = y - 1;
					break;
				case 'O':
				case 'Q':
					if (map->map[y - 2][x] != '#'&&map->map[y - 2][x] != 'O'&&map->map[y - 2][x] != 'Q') {
						if (map->map[y - 2][x] == 'X')
							map->map[y - 2][x] = 'Q';
						else
							map->map[y - 2][x] = 'O';
						map->map[y - 1][x] = '@';
						map->map[y][x] = ' ';
						y = y - 1;
					}
					break;
				default:
					break;
				}

				break;
			case 'S':
			case 's':

				switch (map->map[y + 1][x])
				{
				case ' ':
				case 'X':
					map->map[y + 1][x] = '@';
					map->map[y][x] = ' ';
					y = y + 1;
					break;
				case 'O':
				case 'Q':
					if (map->map[y + 2][x] != '#'&&map->map[y + 2][x] != 'O'&&map->map[y + 2][x] != 'Q') {
						if (map->map[y + 2][x] == 'X')
							map->map[y + 2][x] = 'Q';
						else
							map->map[y + 2][x] = 'O';

						map->map[y + 1][x] = '@';
						map->map[y][x] = ' ';
						y = y + 1;
					}
					break;
				default:
					break;
				}

				break;
			case 'A':
			case 'a':
				switch (map->map[y][x - 1])
				{
				case ' ':
				case 'X':
					map->map[y][x - 1] = '@';
					map->map[y][x] = ' ';
					x = x - 1;
					break;
				case 'O':
				case 'Q':
					if (map->map[y][x - 2] != '#'&&map->map[y][x - 2] != 'O'&&map->map[y][x - 2] != 'Q') {
						if (map->map[y][x - 2] == 'X')
							map->map[y][x - 2] = 'Q';
						else
							map->map[y][x - 2] = 'O';
						map->map[y][x - 1] = '@';
						map->map[y][x] = ' ';
						x = x - 1;
					}
					break;
				default:
					break;
				}

				break;
			case 'D':
			case 'd':
				switch (map->map[y][x + 1])
				{
				case ' ':
				case 'X':
					map->map[y][x + 1] = '@';
					map->map[y][x] = ' ';
					x = x + 1;
					break;
				case 'O':
				case 'Q':
					if (map->map[y][x + 2] != '#'&&map->map[y][x + 2] != 'O'&&map->map[y][x + 2] != 'Q') {
						if (map->map[y][x + 2] == 'X')
							map->map[y][x + 2] = 'Q';
						else
							map->map[y][x + 2] = 'O';
						map->map[y][x + 1] = '@';
						map->map[y][x] = ' ';
						x = x + 1;
					}
					break;
				default:
					break;
				}
				break;
			case 27:

				isEnd = 1;
				break;
			default:
				break;
			}
			break;
		case 1:
			switch (key)
			{
			case 'R':
			case'r':
				scenes = 0;
				map = LoadMap(map->level);


				break;
			case 'N':
			case 'n':
				scenes = 0;
				map = LoadMap(map->level + 1);

				break;

			case 27:
				isEnd = 1;
				break;
			default:
				break;
			}
			break;
		default:
			break;
		}
		int isOver = 1;
		switch (scenes)
		{
		case 0:


			for (int i = 0; i < aim_count; i++) 
			{
				if (map->map[aimy[i]][aimx[i]] != 'Q')
					isOver = 0;
			}
			if (isOver)
				scenes = 1;

			for (int i = 0; i < aim_count; i++) 
			{
				if (map->map[aimy[i]][aimx[i]] == ' ')
					map->map[aimy[i]][aimx[i]] = 'X';
			}
			break;
		case 1:break;
		default:
			break;
		}
		if (isEnd)
			break;
	}
	
	return level++;
}

Map* LoadMap(int level) {

	Map *temp = (Map*)malloc(sizeof(Map));
	char buffer[256];
	
	sprintf_s(buffer, "data/Map/%d.txt", level);

	if ((fp = fopen(buffer, "r")) == NULL)
	{
		printf("�ļ���ʧ�ܣ�");
		exit(1);
	}

	temp->level = level;

	for (int i = 0;; i++) 
	{
		fgets(temp->map[i], 256, fp);
		temp->map[i][strlen(temp->map[i]) - 1] = '\0';
		if (temp->map[i][1] == '|') 
		{
			temp->map[i][1] = '=';
			temp->h = i + 1;
			break;
		}
	}

	fclose(fp);
	return temp;
}