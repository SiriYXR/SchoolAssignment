#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
//#include <graphics.h>
#include <conio.h>
#define N 9
#define M 9
#define _CRT_SECURE_NO_WARNINGS 
//0�ǿ����ߵĵط���1��ǽ��2�����ӣ�3�� Ҫ�����λ�ã�4����
int map[N][M] ={
{1,1,1,1,1,0,0,0,0},
{1,5,0,0,1,0,0,0,0},
{1,0,4,4,1,0,1,1,1},
{1,0,4,0,1,0,1,3,1},
{1,1,1,0,1,1,1,3,1},
{0,1,1,0,0,0,0,3,1},
{0,1,0,0,0,1,0,0,1},
{0,1,0,0,0,1,1,1,1},
{0,1,1,1,1,1,0,0,0},
 };//��ͼ
int main()
{
	int n=0;//�м�����λ�ˣ�
	int x = 1, y = 1;
	char ch;
	for (int i = 0; i < 9; i++)
	{
		for (int j = 0; j < 9; j++)
		{
			switch (map[i][j])
			{
			case 0:
				printf("  "); break;
			case 1:
				printf("��"); break;
			case 3:
				printf("��"); break;
			case 4:
				printf("��"); break;
			case 7:
				printf("��"); break;
			case 5:
			case 8:
				printf("��"); break;

			}
		}
		printf("\n");

	}
	while (1)
	{
		ch = _getch();
		if (ch == 'w')
		{
			if (map[x - 1][y] == 0||map[x-1][y]==3)
			{
				map[x - 1][y] = map[x - 1][y] + 5;
				map[x][y] = map[x][y]-5;
				x--;
			}
			else if (map[x - 1][y] >= 4&&map[x - 2][y] != 1 && map[x - 2][y] != 7 && map[x - 2][y] != 4)
			{
				map[x - 2][y] = map[x - 2][y] + 4;
				map[x - 1][y] = map[x - 1][y] - 4 + 5;
				map[x][y] = map[x][y]-5;
				x--;
				//�����վ��Ŀ��㣬�õ������8��
			}
			else
				continue;
		}
		if (ch == 's')
		{
			if (map[x + 1][y] == 0 || map[x + 1][y] == 3)
			{
				map[x + 1][y] = map[x + 1][y] + 5;
				map[x][y] = map[x][y] - 5;
				x++;
			}
			else if (map[x + 1][y] >= 4&&map[x + 2][y] != 1 && map[x + 2][y] != 7 && map[x + 2][y] != 4)
			{
				map[x + 2][y] = map[x + 2][y] + 4;
				map[x + 1][y] = map[x + 1][y] - 4 + 5;
				map[x][y] = map[x][y] - 5;
				x++;
			}
			else
				continue;
		}
		if (ch == 'a')
		{
			if (map[x][y-1] == 0 || map[x][y-1] == 3)
			{
				map[x][y-1] = map[x][y-1] + 5;
				map[x][y] = map[x][y] - 5;
				y--;
			}
			else if (map[x][y-1] >= 4&&map[x][y-2] != 1 && map[x][y - 2] != 7 && map[x][y - 2] != 4)
			{
				map[x][y-2] = map[x][y-2] + 4;
				map[x][y-1] = map[x][y-1] - 4 + 5;
				map[x][y] = map[x][y] - 5;
				y--;
			}
			else
				continue;
		}
		if (ch == 'd')
		{
			if (map[x][y + 1] == 0 || map[x][y + 1] == 3)
			{
				map[x][y + 1] = map[x][y + 1] + 5;
				map[x][y] = map[x][y] - 5;
				y++;
			}
			else if (map[x][y + 1] >= 4&&map[x][y + 2] != 1&& map[x][y + 2] != 7 && map[x][y + 2] != 4)
			{
				map[x][y + 2] = map[x][y + 2] + 4;
				map[x][y + 1] = map[x][y + 1] - 4 + 5;
				map[x][y] = map[x][y] - 5;
				y++;
			}
			else
				continue;
		}
		system("cls");

		for (int i = 0; i < 9; i++)
		{
			for (int j = 0; j < 9; j++)
			{
				switch (map[i][j])
				{
				case 0:
					printf("  "); break;
				case 1:
					printf("��"); break;
				case 3:
					printf("��"); break;
				case 4:
					printf("��"); break;
				case 7:
					printf("��"); break;
				case 5:
				case 8:
					printf("��"); break;

				}
			}
			printf("\n");

		}
		n = 0;//��ʼ��
		for (int i = 0; i < 9; i++)
		{
			for (int j = 0; j < 9; j++)
			{
				if (map[i][j] == 7)
					n++;
			}
			printf("\n");
		}

		if (n == 3)
			break;
	}
	
}
